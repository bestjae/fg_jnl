##! /bin/bash 
##
## Copyright(c) 2017 All rights reserved by Yongjae Choi. 
## 
## File Name : kernel.sh
## Purpose : 
## Creation Date : 2017-01-03
## Last Modified : 2017-02-05 04:44:21
## Created By : Yongjae Choi <bestjae@naver.com>
## 
##
#
#
#sudo apt-get install build-essential libncurses5 libncurses5-dev bin86 kernel-package -y
#sudo apt-get install libssl-dev bc -y
#
#
#pushd /usr/src 
#
#sudo wget https://cdn.kernel.org/pub/linux/kernel/v4.x/linux-4.9.tar.xz 
#
#sudo tar -xvf linux-4.9*
#
#popd

pushd /usr/src/linux-4.9/ 

make clean

make oldconfig

make -j 8 

make modules

make modules_install

make install

popd
