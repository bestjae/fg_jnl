#! /bin/bash 
#
# Copyright(c) 2016 All rights reserved by Yongjae Choi. 
# 
# File Name : kernel.sh
# Purpose : 
# Creation Date : 2017-02-05
# Last Modified : 2017-02-05 04:42:13
# Created By : Yongjae Choi <bestjae@naver.com>
# 
#

cd ~/linux 

make -j9 && make install && reboot

